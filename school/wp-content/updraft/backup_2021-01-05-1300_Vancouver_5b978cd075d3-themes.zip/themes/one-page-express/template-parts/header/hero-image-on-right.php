<div class="row header-description-row">
    <div class="header-description-right">
        <div class="header-content">
            <div class="align-holder">
                <?php one_page_express_print_header_content(); ?>
            </div>
        </div>
    </div>
    <div class="header-description-left">
        <?php one_page_express_print_header_image(); ?>
    </div>
</div>
